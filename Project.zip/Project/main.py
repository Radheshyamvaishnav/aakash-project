from heapq import nlargest                                       
from string import punctuation

import pyrebase               
import spacy
from flask import Flask, request, render_template
from spacy.lang.en.stop_words import STOP_WORDS

app = Flask(__name__)

#----------> Firebase Authentication

firebaseConfig = {
    "apiKey": "AIzaSyC57Pr-Hiio1MUlYnwHW72s_p9Nh-XNx2o",
    "authDomain": "text-summary-89695.firebaseapp.com",
    "projectId": "text-summary-89695",
    "storageBucket": "text-summary-89695.appspot.com",
    "messagingSenderId": "754918440766",
   " appId": "1:754918440766:web:f6e23490cd90b2771a766f",
    "measurementId": "G-W7TMR79Y5T",
    "databaseURL" : ""
  }

firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()  

nlp = spacy.load('en_core_web_sm')

##################---------->LOGIN
@app.route('/', methods=['GET', 'POST'])
def my_form():
        suser = request.form.get('your_name')
        spass = request.form.get('your_pass')
        try:
            log = auth.sign_in_with_email_and_password(suser, spass)
            return render_template('Summary.html')
        except:
            errmsg = "Enter Correct Credentials"
            return render_template('login.html',umessage=errmsg )
        return render_template('login.html')
#############------------->REGISTER
@app.route('/register', methods=['GET', 'POST'])
def register():
        try:
            if request.method == 'POST':
                    email = request.form.get('email')
                    password = request.form.get('pass')

                    userr = request.form['name']
                    user = auth.create_user_with_email_and_password(email, password)
                    
                    #usera = auth.send_email_verification(email)
                    #vms = "Check Email For Verification Then Login"
                    return render_template('Summary.html')
        except:
                    err = " Email Id Already Exists please login "
                    return render_template('login.html', er=err)
        return render_template('register.html')
    ###################-------->SUMMARY
@app.route('/summary', methods=['GET', 'POST'])
def summary():
    try:
            if request.method == 'POST':
                text = request.form['message']
                doc = nlp(text)

                stopwords = list(STOP_WORDS) + list(punctuation) + ['\n']

                word_frequency = {}
                for word in doc:
                    if word.text.lower() not in stopwords:
                        if word.text not in word_frequency.keys():
                            word_frequency[word.text] = 1
                        else:
                            word_frequency[word.text] += 1

                max_frequency = max(word_frequency.values())

                for word in word_frequency.keys():
                    word_frequency[word] = word_frequency[word] / max_frequency

                sentence_tokens = [sent for sent in doc.sents]

                sentence_score = {}

                for sent in sentence_tokens:
                    for word in sent:
                        if word.text.lower() in word_frequency.keys():
                            if sent not in sentence_score.keys():
                                sentence_score[sent] = word_frequency[word.text.lower()]
                            else:
                                sentence_score[sent] += word_frequency[word.text.lower()]

                para_length = int(len(sentence_tokens) * (30 / 100))

                summary = nlargest(para_length, sentence_score, key=sentence_score.get)

                final_summary = [word.text for word in summary]

                summary = ' '.join(final_summary)
                print(summary)

                return render_template('Result.html', data=summary)
    except:
            msg = "Enter Valid text"
            return render_template('Summary.html', mmsg=msg)

    return render_template('Summary.html')

if __name__ == "__main__":
    app.run(debug = True)